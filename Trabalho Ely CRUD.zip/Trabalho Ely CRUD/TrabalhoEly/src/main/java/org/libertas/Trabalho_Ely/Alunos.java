package org.libertas.Trabalho_Ely;

public class Alunos {
	private int idalunos;
	
	private String nome;
	private String idade;
	private String curso;
	private String periodo;
	private String universidade;

	
	public String getPeriodo() {
		return periodo;
	}
	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}
	public String getUniversidade() {
		return universidade;
	}
	public void setUniversidade(String universidade) {
		this.universidade = universidade;
	}
	public int getIdalunos() {
		return idalunos;
	}
	public void setIdalunos(int idalunos) {
		this.idalunos = idalunos;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getIdade() {
		return idade;
	}
	public void setIdade(String idade) {
		this.idade = idade;
	}
	public String getCurso() {
		return curso;
	}
	public void setCurso(String curso) {
		this.curso = curso;
	}

	@Override
	public String toString() {
		return "";
	}

	
	
}
