package org.libertas.Trabalho_Ely;

public class Pesquisa {
	private String pesquisa;
	
	public String getPesquisa() {
		return pesquisa;
	}
	
	public void setPesquisa(String pesquisa) {
		this.pesquisa = pesquisa;
	}
	
}
