package org.libertas;

public class Pesquisa {
	private String pesquisa;
	
	public String getPesquisa() {
		return pesquisa;
	}
	
	public void setPesquisa(String pesquisa) {
		this.pesquisa = pesquisa;
	}
	
}
